<?php
$emailku = 'emailmu@gmail.com'; // GANTI EMAIL KAMU DISINI
?>